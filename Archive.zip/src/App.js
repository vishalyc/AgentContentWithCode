import React, { Component } from 'react';
import './App.css';
import store from "./store/store";
import { Provider } from "react-redux";
import AgentContent from './containers/agentContentContainer'

import { ApolloClient } from 'apollo-client'
import { createHttpLink } from 'apollo-link-http'
import { InMemoryCache } from 'apollo-cache-inmemory'

const httpLink = createHttpLink({
    uri: 'http://localhost:4000'
})

const apolloGraphClient = new ApolloClient({
    link: httpLink,
    cache: new InMemoryCache(),
})
  

//AWS Amplify configuration
class App extends Component {
    constructor() {
        super ();
        this.state = {
            queryParams: {
                name: "SAYHELLO", 
                feature: "SEARCHANDLOCATE", 
                client: "Verizon", 
                language: "en-US", 
                type: "Speak" 
            },
            queryParams1: {
                name: "SAYBYE", 
                feature: "SEARCHANDLOCATE", 
                client: "Verizon", 
                language: "en-US", 
                type: "Speak" 
            }
        }
    }

    changeQueryParms = () => {
        this.setState (
            {
                queryParams: {
                    name: "SAYBYE", 
                    feature: "SEARCHANDLOCATE", 
                    client: "Verizon", 
                    language: "en-US", 
                    type: "Speak" 
                }
            }
        )
    }

    render() {
        return (
            <div className="App">
                <Provider store={store}>
                    <AgentContent params={ this.state.queryParams } replaceVariables={ { __claimID__:"123456", __OrderID__: "343433434" } } apolloGraphClient={ apolloGraphClient } callInformation={ { interactionID:'43434343434' } } />
                    { /* <AgentContent params={ this.state.queryParams1 } replaceVariables={ { __claimID__:"6736783478634768", __OrderID__: "343433434" } }/> */ }
                    <button onClick={ this.changeQueryParms } > Change Parameter </button>
                </Provider>
            </div>
        );
    }
}

export default App