import gql from "graphql-tag";
import { graphqluri } from '../configs/graphQLconfig'

const { createApolloFetch } = require('apollo-fetch');

const GetDataFromGraph = function (params, apolloGraphClient) {
    if (apolloGraphClient === undefined || apolloGraphClient === null) {
        return new Promise(
            function (resolve, reject) {
                //instead of using apollo fetch use the apollo client from the consumers if available else use this.
                const fetch = createApolloFetch({ //make the function also configurable
                    uri: graphqluri, //make this configurable
                });

                fetch({
                    query: `query agentScriptByParams($name: String!, $feature: String!, $client: String!, $language: String!, $type: String!) {
                        agentScriptByParams(name: $name, feature: $feature, client: $client, language: $language, type: $type) {
                            name
                            feature
                            client
                            scripts {
                                script
                            }
                        }
                    }`,
                    variables: { name: params.name, feature: params.feature, client: params.client, language: params.language, type: params.type },
                }).then(res => {
                    console.log(res.data);
                    resolve (res.data); 
                }).catch (error => {
                    console.log(error);
                    reject (error);
                });
            }
        )
    }
    else {
        return new Promise(
            function (resolve, reject) {
                apolloGraphClient.query({
                    query: gql `query agentScriptByParams($name: String!, $feature: String!, $client: String!, $language: String!, $type: String!) {
                        agentScriptByParams(name: $name, feature: $feature, client: $client, language: $language, type: $type) {
                            name
                            feature
                            client
                            scripts {
                                script
                                type
                                language
                                dateCreated
                                createdBy
                            }
                        }
                    }`,
                    variables: { name: params.name, feature: params.feature, client: params.client, language: params.language, type: params.type },
                }).then(res => {
                    console.log(res.data);
                    resolve (res.data);
                }).catch (error => {
                    console.log(error);
                    reject (error);
                });
            }
        )
    }
}

export default GetDataFromGraph;