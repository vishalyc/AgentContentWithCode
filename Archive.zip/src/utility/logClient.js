import { Analytics, AWSKinesisProvider } from 'aws-amplify';
import config from '../configs/awsKinesisConfig';
import GetCurentDateTime from '../utility/datetime'

Analytics.addPluggable(new AWSKinesisProvider());

Analytics.configure(config.Amplify);

export default async function LogAgentContent (data) {
    try {
        await Analytics.record({
            data: { 
                type: 'AgentScriptLog',
                message: data,
                timestamp: GetCurentDateTime(),
                application: 'ALPHA'
            },
            partitionKey: config.partitionKey, 
            streamName: config.streamName
        }, 'AWSKinesis');
        console.log ("Uploaded to Kinesis");
    } catch (err) {
        console.log (err);
    }
}