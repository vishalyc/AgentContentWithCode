export const ADD_CONTENT = 'ADD_CONTENT';
export const ADD_PARAMS = 'ADD_PARAMS';
export const GET_CONTENT = 'GET_CONTENT';

export function addContent(agentScriptPayLoad) {
    return { type: ADD_CONTENT, agentScriptPayLoad }
}

export function getContent (agentScriptPayLoad) {
    return { type: GET_CONTENT, agentScriptPayLoad }
}

export function addParams(paramsPayLoad) {
    return { type: ADD_PARAMS, paramsPayLoad }
}
