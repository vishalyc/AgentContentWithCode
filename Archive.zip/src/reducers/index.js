import { combineReducers } from 'redux';
import addContentToStore from './addcontentReducer'

const agentContentRootReducer = combineReducers({
  addContentToStore: addContentToStore,
});

export default agentContentRootReducer;