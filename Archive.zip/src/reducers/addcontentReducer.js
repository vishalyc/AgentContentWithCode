import { ADD_CONTENT } from '../actions/actions'

const initialState = {
    agentContent: []
}

const addContentToStore = (state = initialState, action) => {
    if (action.type === ADD_CONTENT) {
        const newState =  Object.assign( 
            {}, 
            state,
            state.agentContent.push (action.agentScriptPayLoad)
        );

        return newState;
    }
    else
        return state;
}

export default addContentToStore;