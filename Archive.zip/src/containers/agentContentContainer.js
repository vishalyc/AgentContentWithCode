import React, { Component } from 'react'
import { connect } from 'react-redux'
import { addContent, getContent } from '../actions/actions'
//import store from "../store/store";

import GetDataFromGraph from '../utility/graphClient'
import LogAgentContent from '../utility/logClient'

function mapStateToProps (state, myState) {
    let agentContentState;
    try {
        agentContentState = state.addContentToStore.agentContent.find ( agentScript => agentScript.agentScriptByParams.name ===  myState.params.name );
    } catch (err) {
        const logData = {
            interactionId: myState.interactionID,
            params: myState.params.name + '_' + myState.params.feature + '_' + myState.params.client + '_' + myState.params.language + '_' + myState.params.type,
            agentScript: state.addContentToStore.agentContent,
            type: 'EXCEPTION',
        }
        LogAgentContent (logData);
    }

    if (agentContentState !== undefined) {
        agentContentState = agentContentState ["agentScriptByParams"]["scripts"][0].script;    
        agentContentState = replaceScriptVariables(myState.replaceVariables, agentContentState);
    
        //Create data to log to kineses stream
        const logData = {
            interactionId: myState.interactionID,
            params: myState.params.name + '_' + myState.params.feature + '_' + myState.params.client + '_' + myState.params.language + '_' + myState.params.type,
            agentScript: agentContentState,
            type: 'INFORMATION',
        }
        LogAgentContent (logData);
    }

    return { agentContentState };
}

function mapDispatchToProps(dispatch, myState) {
    let key = myState.params.name + '_' + myState.params.feature + '_' + myState.params.client + '_' + myState.params.language + '_' + myState.params.type;
    //Check if session has the key so that it can be pulled from redux store

    if (sessionStorage.getItem (key)) {
        return {
            addContentToStore: (agentScript) => dispatch(getContent(agentScript))
        };
    }
    else {
        return {
            addContentToStore: (agentScript) => dispatch(addContent(agentScript))
        };
    }
}

function checkParamsInCache (newParams) {
    let value = '';
    let key = newParams.name + '_' + newParams.feature + '_' + newParams.client + '_' + newParams.language + '_' + newParams.type;
    if (sessionStorage.hasOwnProperty(key)) {
        value =  JSON.parse (sessionStorage.getItem (key));     
    }
    
    return value;
}

function replaceScriptVariables (mapObj, str) {
    let hasVariableReplaced = false;
    if ( !(str === undefined) ) {
        var re = new RegExp(Object.keys(mapObj).join("|"),"gi");
        try {
            str = str.replace(re, function(matched) {
                return mapObj[matched];
                hasVariableReplaced = true;
            });
        } catch (err) {
            
        }
    }
    if (!hasVariableReplaced)
        return str;
}

class ConnectedAgentContent extends Component {
    constructor (props) {
        super (props);

        //fetch evertthing from DB into redux store. 
    }

    componentDidMount () {
        //Add queryParams to state
        this.setState ({  params: this.props.params } );

        //Add Replace variables to state
        this.setState ({ replaceVariables: this.props.params })
        
        const newParams= this.props.params;
        const apolloGraphClient = this.props.apolloGraphClient; //This is the apollo graph client sent by consumers in parameters

        if (!checkParamsInCache (newParams)) {
            GetDataFromGraph (newParams, apolloGraphClient).then (
                agentScript => {
                    this.props.addContentToStore (agentScript);
                    let key =  newParams.name + '_' + newParams.feature + '_' + newParams.client + '_' + newParams.language + '_' + newParams.type;
                    sessionStorage.setItem(key, "true");
                }
            ); 
        }
        else {      
                this.props.addContentToStore ('');
        }
    }

    componentWillReceiveProps(nextProps) {
        const newParams = nextProps.params;
        
        if (!checkParamsInCache (newParams)) {
            GetDataFromGraph (newParams).then (
                agentScript => {
                    this.props.addContentToStore (agentScript);
                }
            ); 
        }
        else {      
            this.props.addContentToStore ('');
        }
    }

    render () {
        return (
            <p>
                { JSON.stringify ( this.props.agentContentState )}
            </p>
        )
    }
}

const AgentContent = connect(mapStateToProps, mapDispatchToProps)(ConnectedAgentContent);
export default AgentContent;
