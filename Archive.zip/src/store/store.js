import { createStore } from 'redux'
import agentContentRootReducer from '../reducers/'
 
export default createStore(
    agentContentRootReducer
)